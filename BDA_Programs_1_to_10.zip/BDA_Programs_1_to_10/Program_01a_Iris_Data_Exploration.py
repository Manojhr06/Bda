import pandas as pd

url = "https://raw.githubusercontent.com/mwaskom/seaborn-data/master/iris.csv"
data = pd.read_csv(url)

print(data.head())
print(data.shape)
print(data.columns.tolist())
print(data.dtypes)
data.info()
print(data.describe())
print(data.isnull().sum())
