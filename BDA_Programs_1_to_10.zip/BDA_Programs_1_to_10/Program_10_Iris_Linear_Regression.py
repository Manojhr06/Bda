import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

url = "https://raw.githubusercontent.com/mwaskom/seaborn-data/master/iris.csv"
df = pd.read_csv(url)

X = df[["petal_length"]]
y = df["sepal_length"]

model = LinearRegression().fit(X, y)
predictions = model.predict(X)

print(predictions[:5])

plt.scatter(X, y)
sorted_idx = X["petal_length"].argsort()
plt.plot(X["petal_length"].iloc[sorted_idx], predictions[sorted_idx], "r")
plt.show()
