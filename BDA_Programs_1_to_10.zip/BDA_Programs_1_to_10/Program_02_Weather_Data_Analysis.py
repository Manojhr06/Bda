import pandas as pd
import matplotlib.pyplot as plt

# Keep 1. Weather_Data.csv in the same folder as this program.
df = pd.read_csv("1. Weather_Data.csv").dropna(axis=1)
df.rename(columns={"Weather": "Weather_Condition"}, inplace=True)

print(df.shape, df.isnull().sum())
print(df["Weather_Condition"].value_counts())
print(df.describe())

df.plot(x="Date/Time", y="Temp_C")
plt.show()

counts = df["Weather_Condition"].value_counts()
counts.loc[counts > 20].plot.pie(autopct="%1.1f%%")
plt.show()
