import pandas as pd

url = "https://raw.githubusercontent.com/mwaskom/seaborn-data/master/iris.csv"
df = pd.read_csv(url).drop_duplicates()

print(df.head())
df.info()
print(df.describe())
print(df.isnull().sum())

print(df[df.species == "setosa"].head())
print(df.sort_values("sepal_length").head())
print(df.groupby("species").sepal_length.agg(["count", "mean"]))

df["SepalArea"] = df.sepal_length * df.sepal_width
df.to_csv("Processed_Iris.csv", index=False)
print("Saved Processed_Iris.csv")
