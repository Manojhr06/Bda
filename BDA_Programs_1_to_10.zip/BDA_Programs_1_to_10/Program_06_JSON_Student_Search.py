import json

students = [
    {"ID": 101, "Name": "Shashank", "Age": 22, "Course": "CSE"},
    {"ID": 102, "Name": "Vinay", "Age": 21, "Course": "ECE"},
    {"ID": 103, "Name": "Ram", "Age": 23, "Course": "CSE"}
]

with open("students.json", "w", encoding="utf-8") as f:
    json.dump(students, f, indent=4)

with open("students.json", "r", encoding="utf-8") as f:
    data = json.load(f)

print(data)

name = input("Enter name: ")
print([s for s in data if s["Name"].lower() == name.lower()])

course = input("Enter course: ")
print([s for s in data if s["Course"].lower() == course.lower()])

age = int(input("Minimum age: "))
print([s for s in data if s["Age"] >= age])
