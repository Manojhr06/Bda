import json

filename = "Students.json"

while True:
    try:
        with open(filename, "r", encoding="utf-8") as file:
            students = json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        students = []

    choice = input("\\n1.Add 2.Read 3.Update 4.Delete 5.Exit: ")

    if choice == "1":
        students.append({
            "ID": input("ID: "),
            "Name": input("Name: "),
            "Age": input("Age: "),
            "Course": input("Course: ")
        })
    elif choice == "2":
        print(students)
    elif choice in ["3", "4"]:
        student_id = input("Enter ID: ")
        student = next((x for x in students if x["ID"] == student_id), None)

        if student:
            if choice == "3":
                student["Name"] = input("New name: ")
            else:
                students.remove(student)
        else:
            print("Not found")
    elif choice == "5":
        break
    else:
        print("Invalid choice")
        continue

    if choice != "2":
        with open(filename, "w", encoding="utf-8") as file:
            json.dump(students, file, indent=4)
