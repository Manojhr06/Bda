import pandas as pd

url = "https://raw.githubusercontent.com/mwaskom/seaborn-data/master/iris.csv"
data = pd.read_csv(url)

data = data.fillna(0).drop_duplicates()
data.columns = ["SepalLength", "SepalWidth", "PetalLength", "PetalWidth", "Species"]
print(data.head())
