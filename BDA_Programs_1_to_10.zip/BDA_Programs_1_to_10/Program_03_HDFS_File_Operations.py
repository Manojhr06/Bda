import os
import shutil

os.makedirs("HDFS/input", exist_ok=True)
os.makedirs("HDFS/output", exist_ok=True)
os.makedirs("HDFS/backup", exist_ok=True)

with open("HDFS/input/data.txt", "w", encoding="utf-8") as f:
    f.write("Welcome to HDFS")

shutil.copy("HDFS/input/data.txt", "HDFS/backup/")
shutil.move("HDFS/input/data.txt", "HDFS/output/")
os.rename("HDFS/output/data.txt", "HDFS/output/final.txt")

for root, dirs, files in os.walk("HDFS"):
    print(root, dirs, files)

# WARNING: This deletes the entire local HDFS folder created above.
shutil.rmtree("HDFS")
