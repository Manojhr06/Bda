# In Jupyter, install first with: %pip install pyspark
from pyspark.sql import SparkSession
from pyspark.sql.functions import max, min

spark = SparkSession.builder.appName("Students").getOrCreate()

data = [
    (101, "Rahul", "CSE", 85),
    (102, "Priya", "ISE", 90),
    (103, "Arun", "CSE", 78),
    (104, "Sneha", "ECE", 88)
]

df = spark.createDataFrame(data, ["ID", "Name", "Department", "Marks"])

df.show()
df.filter(df.Marks > 80).show()
df.groupBy("Department").avg("Marks").show()
df.agg(max("Marks"), min("Marks")).show()

spark.stop()
