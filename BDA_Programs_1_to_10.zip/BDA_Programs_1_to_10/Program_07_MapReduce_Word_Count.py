n = int(input("Number of lines: "))
words = []

for _ in range(n):
    words += input().lower().split()

print("Map:", [(word, 1) for word in words])

count = {word: words.count(word) for word in set(words)}
print("Reduce (Word Count):", count)
