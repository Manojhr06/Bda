import pandas as pd

users = pd.DataFrame({
    "action": ["login", "logout", "login"],
    "timestamp": ["10:00", "10:15", "10:30"]
})

print("Hive:\\n", users.groupby("action").size())
print(users)

logs = pd.DataFrame({"type": ["info", "error", "error"]})
print("Pig:\\n", logs[logs.type == "error"].groupby("type").size())
print(logs)
