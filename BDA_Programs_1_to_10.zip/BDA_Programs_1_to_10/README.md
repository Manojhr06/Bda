# BDA Practical Programs 1–10

This folder contains the Python programs in order. Program 1 has two parts (1a and 1b), so there are 11 Python files.

## Programs
1. `Program_01a_Iris_Data_Exploration.py` — Iris data exploration
2. `Program_01b_Iris_Data_Cleaning.py` — Iris data cleaning
3. `Program_02_Weather_Data_Analysis.py` — Weather data analysis and visualization
4. `Program_03_HDFS_File_Operations.py` — Local file operations simulating HDFS
5. `Program_04_Iris_Filter_Sort_Group.py` — Iris filtering, sorting, grouping and CSV output
6. `Program_05_Student_Management_JSON.py` — Student CRUD operations with JSON
7. `Program_06_JSON_Student_Search.py` — Search and filter student records
8. `Program_07_MapReduce_Word_Count.py` — Word-count MapReduce simulation
9. `Program_08_Hive_Pig_Pandas_Simulation.py` — Hive/Pig concepts simulated with Pandas
10. `Program_09_PySpark_Student_Processing.py` — PySpark DataFrame operations
11. `Program_10_Iris_Linear_Regression.py` — Linear regression with Iris data

## Dependencies
Install common dependencies with:

```bash
python -m pip install pandas matplotlib scikit-learn pyspark
```

For Program 2, place `1. Weather_Data.csv` in the same directory and make sure its columns include `Weather`, `Date/Time`, and `Temp_C`.

Program 3 deletes the local `HDFS` directory at the end. Use it only in a test folder.
